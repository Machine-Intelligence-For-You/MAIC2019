from copy import deepcopy
import random

from player import Player, TILES_COLOR


INF = float("inf")
N_PIECES, N_ROWS, N_COLUMNS = 12, 5, 6

PLACE, SIMPLE_MOVE, CAPTURE_MOVE = 1, 2, 3

MAX_DEPTH, HAND_LIMIT = 3, 4

SAFE_DIST = 3
MAX_DIST = max(N_ROWS, N_COLUMNS)

ILLEGAL_MOVE = (0, 0)

def manhattan_distance(cellA, cellB):
    return abs(cellA[0]-cellB[0]) + abs(cellA[1]-cellB[1])

def count_color_on_board(color, board):
    return sum(row.count(color) for row in board)

def color_positions_on_board(color, board):
    positions = list()
    for i in range(N_ROWS):
        for j in range(N_COLUMNS):
            if board[i][j] == color:
                positions.append((i, j))
    return positions

def cell_between(cellA, cellB):
    return (cellA[0]+cellB[0])//2, (cellA[1]+cellB[1])//2

def is_on_board(x, y):
    return 0<=x<N_ROWS and 0<=y<N_COLUMNS

def min_dist_to_opponent(cell, opponent_positions=None, board=None):
    if opponent_positions:
        result = MAX_DIST
        for pos in opponent_positions:
            result = min(result, manhattan_distance(cell, pos))
        return result
    if board:
        x, y = cell
        color = board[x][y]
        opponent_color = TILES_COLOR[1-TILES_COLOR.index(color)]
        opponent_positions = color_positions_on_board(opponent_color, board)
        return min_dist_to_opponent(cell, opponent_positions=opponent_positions)
    return MAX_DIST
    

def min_dist_between_opponents(board):
    # todo: optimize this
    positions_0 = color_positions_on_board(TILES_COLOR[0], board)
    positions_1 = color_positions_on_board(TILES_COLOR[1], board)
    result = INF
    for pos0 in positions_0:
        result = min(result, min_dist_to_opponent(pos0, positions_1))
    return result

def is_board_safe(board):
    return min_dist_between_opponents(board) >= SAFE_DIST
    

class Action:
    def __init__(self, description, cells_implied):
        self.description = description
        self.cells_implied = cells_implied
        
    def get_end_cell(self):
        if self.description == PLACE:
            return self.cells_implied[0]
        else:
            return self.cells_implied[1]
        
    def __eq__(self, action):
        return self.cells_implied == action.cells_implied

class State:
    def __init__(self, player_number, board, pieces_count, first_capture_depth=None, spawner_action=None):
        self.board = board
        self.player_number = player_number
        self.opponent_number = 1 - player_number
        self.pieces_count = pieces_count
        self.first_capture_depth = first_capture_depth if first_capture_depth else {0: MAX_DEPTH, 1: MAX_DEPTH}
        self.spawner_action = spawner_action
    
    @property
    def player_color(self):
        return TILES_COLOR[self.player_number]
    
    @property
    def opponent_color(self):
        return TILES_COLOR[self.opponent_number]
    
    def __str__(self):
        s = ""
        for i in range(N_ROWS):
            for j in range(N_COLUMNS):
                if self.board[i][j] == self.player_color:
                    s += "1"
                elif self.board[i][j] == self.opponent_color:
                    s += "0"
                else:
                    s += "."
        return s
    
    def pieces_positions(self, is_player_pieces=True):
        color = self.player_color if is_player_pieces else self.opponent_color
        return color_positions_on_board(color, self.board)
    
    def enemy_pieces_positions(self):
        return self.pieces_positions(is_player_pieces=False)
    
    def count_threaten(self, ai_obj):
        # return the number of threat on the opponent
        threaten = {self.player_number: 0, self.opponent_number: 0}
        for i in range(N_ROWS):
            for j in range(N_COLUMNS):
                if self.board[i][j] == self.player_color:
                    threaten[self.player_number] += ai_obj.count_threaten(self.board, (i,j), self.player_number, exclude=[SIMPLE_MOVE])
                elif self.board[i][j] == self.opponent_color:
                    threaten[self.opponent_number] += ai_obj.count_threaten(self.board, (i,j), self.opponent_number, exclude=[SIMPLE_MOVE])
        return threaten
    
    def threaten_diff_score(self, ai_obj):
        threaten = self.count_threaten(ai_obj)
        diff = threaten[self.player_number] - threaten[self.opponent_number]
        return diff + N_PIECES # 0<=x<=24
    
    @property
    def is_root(self):
        return self.spawner_action is None
    
    def permute_players(self):
        self.player_number, self.opponent_number = self.opponent_number, self.player_number

    def contains_less_pieces_of_me_than(self, state):
        if not state:
            return False
        return self.pieces_count[self.player_number]["lost"] > state.pieces_count[self.player_number]["lost"]
    
    def contains_less_pieces_of_opponent_than(self, state):
        if not state:
            return False
        return self.pieces_count[self.opponent_number]["lost"] > state.pieces_count[self.opponent_number]["lost"]
    
    def player_score(self, player_number=None):
        if player_number is None:
            n_pieces_won = self.pieces_count[self.opponent_number]["lost"]
            n_pieces_lost = self.pieces_count[self.player_number]["lost"]
            return n_pieces_won - n_pieces_lost
        
    def n_pieces_in_hands(self):
        return self.pieces_count[self.player_number]["in_hand"] + self.pieces_count[self.opponent_number]["in_hand"]
    
    def log(self):
        s = "VY Log\n"
        s += f"We are the current player ({self.player_color})\n"
        s += f"Board: {self.board}\n"
        s += f"Pieces count: {self.pieces_count}\n\n\n\n"
        print(s)


class Memo:
    def __init__(self, maxsize):
        self.values = []
        self.maxsize = maxsize
        
    def put(self, element):
        self.values.append(element)
        if len(self.values) == self.maxsize + 1:
            self.values.pop(0)
    
    def empty(self):
        return len(self.values)==0
    
    def first(self):
        return self.values[0] if self.values else None
    
    def last(self):
        return self.values[-1] if self.values else None


class AIAbstract(Player):
    def __init__(self, player_number, board_size):
        self.player_pieces = N_PIECES
        self.player_pieces_in_hand = N_PIECES
        self.captured_pieces = 0
        self.player_number = player_number
        self.opponent_number = 1 - player_number
        self.board_size = (N_ROWS, N_COLUMNS)
        self.TILES_COLOR = TILES_COLOR
        self.color = TILES_COLOR[self.player_number]
        self.opponent_color = TILES_COLOR[self.opponent_number]
        self.cache = {"piece_to_steal": None, "prec_actions_sent": Memo(2)}
        self.is_shuffle_strategy = False
        self.n_actions = 0 
        
    def count_threaten(self, board, cell, player_number, exclude=[]):
        comp = 0
        extra_comp = 1
        i, j = cell
        if self.get_possible_moves(cell) is not None:
            for move in self.get_possible_moves(cell):
                if self.is_empty_cell(board, move):
                    if SIMPLE_MOVE not in exclude: comp += 1
                elif self.get_no_empty_cell_color(board, move) != self.TILES_COLOR[player_number]:
                    k, l = move
                    if i == k and j < l and self.is_empty_cell(board, (i, j + 2)):
                        if CAPTURE_MOVE not in exclude: comp += 1
                        if self.get_no_empty_cell_color(board, (i, j+3)) == self.TILES_COLOR[player_number]:
                            comp += extra_comp
                    elif i == k and l < j and self.is_empty_cell(board, (i, j - 2)):
                        if CAPTURE_MOVE not in exclude: comp += 1
                        if self.get_no_empty_cell_color(board, (i, j-3)) == self.TILES_COLOR[player_number]:
                            comp += extra_comp
                    elif j == l and i < k and self.is_empty_cell(board, (i + 2, j)):
                        if CAPTURE_MOVE not in exclude: comp += 1
                        if self.get_no_empty_cell_color(board, (i+3, j)) == self.TILES_COLOR[player_number]:
                            comp += extra_comp
                    elif j == l and k < i and self.is_empty_cell(board, (i - 2, j)):
                        if CAPTURE_MOVE not in exclude: comp += 1
                        if self.get_no_empty_cell_color(board, (i-3, j)) == self.TILES_COLOR[player_number]:
                            comp += extra_comp
            return comp

    def _get_possible_actions(self, state, exclude=[]):
        playable_cells = self.get_all_possibles_moves(state.board, state.player_number)
        actions = {SIMPLE_MOVE: list(), CAPTURE_MOVE: list(), PLACE: list()}
        for start_cell in playable_cells["pieces"]:
            for end_cell in self.get_piece_actual_moves(state.board, start_cell, state.player_number):
                d = manhattan_distance(start_cell, end_cell)
                if d == 1:
                    if SIMPLE_MOVE not in exclude:
                        actions[SIMPLE_MOVE].append(Action(SIMPLE_MOVE, [start_cell, end_cell]))
                elif d==2:
                    if CAPTURE_MOVE not in exclude:
                        captured_piece = cell_between(start_cell, end_cell)
                        if state.pieces_count[state.opponent_number]["in_hand"] > 0:
                            actions[CAPTURE_MOVE].append(Action(CAPTURE_MOVE, [start_cell, end_cell, (-1, -1)]))
                        for enemy_cell in state.enemy_pieces_positions():
                            if enemy_cell != captured_piece:
                                actions[CAPTURE_MOVE].append(Action(CAPTURE_MOVE, [start_cell, end_cell, enemy_cell]))
        if PLACE not in exclude:
            if state.pieces_count[state.player_number]["in_hand"] > 0:
                for cell in playable_cells["empty_cells"]:
                    actions[PLACE].append(Action(PLACE, [cell]))
        
        if self.is_shuffle_strategy:
            random.shuffle(actions[CAPTURE_MOVE])
            random.shuffle(actions[SIMPLE_MOVE])
            random.shuffle(actions[PLACE])
        return actions[CAPTURE_MOVE] + actions[SIMPLE_MOVE] + actions[PLACE]
    
    def _get_actions(self, state, depth=0):
        exclude = list()
        return self._get_possible_actions(state, exclude)

    def _apply_action(self, action, state, depth=0):
        new_player_number = 1 - state.player_number
        new_board = deepcopy(state.board)
        new_pieces_count = deepcopy(state.pieces_count)
        new_first_capture_depth = deepcopy(state.first_capture_depth)
        if action.description == PLACE:
            placement_cell, = action.cells_implied
            new_board[placement_cell[0]][placement_cell[1]] = state.player_color
            new_pieces_count[state.player_number]["on_board"] += 1
            new_pieces_count[state.player_number]["in_hand"] -= 1
        elif action.description == SIMPLE_MOVE:
            start_cell, end_cell = action.cells_implied
            new_board[start_cell[0]][start_cell[1]] = None
            new_board[end_cell[0]][end_cell[1]] = state.player_color
        elif action.description == CAPTURE_MOVE:
            start_cell, end_cell, enemy_piece_to_steal = action.cells_implied
            new_board[start_cell[0]][start_cell[1]] = None
            new_board[end_cell[0]][end_cell[1]] = state.player_color
            middle_cell = cell_between(start_cell, end_cell)
            new_board[middle_cell[0]][middle_cell[1]] = None
            new_pieces_count[state.opponent_number]["on_board"] -= 1
            new_pieces_count[state.opponent_number]["lost"] += 1
            if enemy_piece_to_steal == (-1, -1):
                new_pieces_count[state.opponent_number]["in_hand"] -= 1
            else:
                new_board[enemy_piece_to_steal[0]][enemy_piece_to_steal[1]] = None
                new_pieces_count[state.opponent_number]["on_board"] -= 1
            new_pieces_count[state.opponent_number]["lost"] += 1
            if new_first_capture_depth[state.player_number] == MAX_DEPTH:
                new_first_capture_depth[state.player_number] = depth
        return State(new_player_number, new_board, new_pieces_count, new_first_capture_depth, action)
    
    def _get_successors(self, state, depth=0):
        for action in self._get_actions(state, depth):
            new_state = self._apply_action(action, state, depth)
            yield action, new_state

    def _handle_action(self, action):
        if action.description == PLACE:
            return action.cells_implied[0]
        
        result = action.cells_implied[0] + action.cells_implied[1]
        if action.description == SIMPLE_MOVE:
            return result
        
        if action.description == CAPTURE_MOVE:
            self.cache["piece_to_steal"] = action.cells_implied[2]
            return result
    
    def _get_actual_state(self, board):
        pieces_count = dict()
        on_board = count_color_on_board(self.color, board)
        in_hand = self.player_pieces_in_hand
        lost = N_PIECES - on_board - in_hand
        pieces_count.update({
            self.player_number: {"on_board": on_board, "in_hand": in_hand, "lost": lost}
        })
        on_board = count_color_on_board(self.opponent_color, board)
        lost = self.captured_pieces
        in_hand = N_PIECES - on_board - lost
        pieces_count.update({
            self.opponent_number: {"on_board": on_board, "in_hand": in_hand, "lost": lost}
        })
        return State(self.player_number, board, pieces_count)
    
    def _play(self, depth_to_cover, board, can_steal):
        pass
    
    def play(self, depth_to_cover, board, can_steal):
        try:
            return self._play(depth_to_cover, board, can_steal)
        except:
            return ILLEGAL_MOVE
