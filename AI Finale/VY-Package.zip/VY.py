from vyutils import (N_PIECES, N_ROWS, N_COLUMNS, MAX_DEPTH, MAX_DIST,
                     HAND_LIMIT, INF, min_dist_to_opponent,
                     AIAbstract as VYAIAbstract)
from util import timeout
from time import time  

class AI(VYAIAbstract):
    
    name = "VY"
    
    
    def get_player_name(self):
        return self.name
    
    
    def _is_cuttable(self, state, depth):
        return self.depth == depth
    
    def _evaluate(self, state):
        n_pieces_won = state.pieces_count[self.opponent_number]["lost"]
        n_pieces_lost = state.pieces_count[self.player_number]["lost"]
        h1 = n_pieces_won - n_pieces_lost
        
        threaten = state.count_threaten(self)
        diff = threaten[self.player_number] - threaten[self.opponent_number]
        h2, max_h2 = diff + N_PIECES, (2*N_PIECES+1)*N_ROWS*N_COLUMNS
        
        d = min_dist_to_opponent(state.spawner_action.get_end_cell(), board=state.board)
        if d==1:
            d = MAX_DIST
        h3 = MAX_DIST - d
        max_h3 = MAX_DIST+1
        
        h4 = MAX_DEPTH - state.first_capture_depth[self.player_number] + state.first_capture_depth[self.opponent_number]
        max_h4 = 2*MAX_DEPTH+1
        
        val = state.pieces_count[self.player_number]["in_hand"]
        h5 = val if val<=HAND_LIMIT else 0
        max_h5 = HAND_LIMIT+1
        
        h = (((h1*max_h2 + h2)*max_h3 + h3)*max_h4 + h4)*max_h5 + h5
        
        return h
    
    def _set_depth(self):
        self.depth = 2
        if self.n_actions < 15 and self.n_pieces_in_hands < 2:
            self.depth = 3
        
    def _get_best_action(self, state):
        def max_value(state, alpha, beta, depth):
            if self._is_cuttable(state, depth):
                state_value = self._evaluate(state)
                return state_value, None
            value, action = -INF, None
            successors = list(self._get_successors(state, depth))
            if depth == 0: 
                self.n_actions = len(successors)
                self.n_pieces_in_hands = state.n_pieces_in_hands()
                self._set_depth()
            for action_, new_state in successors:
                v, _ = min_value(new_state, alpha, beta, depth + 1)
                if v > value:
                    value, action = v, action_
                    if v >= beta:
                        return v, action
                    alpha = max(alpha, v)
            return value, action
        
        def min_value(state, alpha, beta, depth):
            if self._is_cuttable(state, depth):
                state_value = self._evaluate(state)
                return state_value, None
            value, action = INF, None
            for action_, new_state in self._get_successors(state, depth):
                v, _ = max_value(new_state, alpha, beta, depth + 1)
                if v < value:
                    value, action = v, action_
                    if v <= alpha:
                        return v, action
                    beta = min(beta, v)
            return value, action
        
        _, action = max_value(state, -INF, INF, 0)
        action = self._handle_action(action)
        return action
    
    @timeout(seconds=0.1)
    def _play(self, depth_to_cover, board, can_steal):
        print("Mon tour")
        start_time = time()
        if can_steal:
            return self.cache["piece_to_steal"]
        actual_state = self._get_actual_state(board)
        self.depth = MAX_DEPTH
        selected_action = self._get_best_action(actual_state)
        if not selected_action:
            actual_state.log()
            raise Exception("No action found")
        end_time = time()
        print(f"{self.name}; Execution time in ms: {1000*(end_time-start_time)}\n")
        self.is_shuffle_strategy = False
        if self.cache["prec_actions_sent"].first() == selected_action:
            if actual_state.player_score() <= 0:
                self.is_shuffle_strategy = True
        self.cache["prec_actions_sent"].put(selected_action)
        return selected_action
